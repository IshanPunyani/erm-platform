# ERM Platform — Python Edition

Enterprise Risk Management web application built with **Python (FastAPI) + SQLite**.  
No React, no npm. Just Python. Run with a single command.

---

## Stack
- **Backend**: FastAPI + Uvicorn
- **Database**: SQLite (`erm.db`) — zero config, all data persists here
- **Templates**: Jinja2 HTML templates
- **Charts**: Chart.js (CDN)
- **Excel**: openpyxl

---

## Quick Start

```bash
# 1. Create and activate a virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # Linux / Mac
venv\Scripts\activate           # Windows

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the app
python main.py
```

Open http://localhost:8000 in your browser.

---

## Features

| Feature | Description |
|---|---|
| **Risk Register** | Full tabular view — all impact sub-scores, sort, filter, inline expand |
| **Add/Edit Risk** | Vertical single-column form, impact basis per dimension, likelihood basis, velocity basis |
| **3D Scoring (NEW)** | Optional Velocity dimension (1–3, time-to-impact) — produces a Score 3D = Impact × Likelihood × Velocity (max 75). 2D Score (max 25) is always computed alongside. |
| **2D / 3D Toggle (NEW)** | Heatmap and Rating Matrix both toggle between 5×5 (Impact × Likelihood) and 15×5 (Impact-Velocity × Likelihood) — choice persisted per-browser |
| **Proposed Plan** | Separate submission by risk owner with name + timestamp |
| **Approval Matrix** | Configurable per rating (Critical/High/Medium/Low) — approve/reject closure |
| **Periodic Reviews (NEW)** | Reviews open automatically when next-assessment-date passes. Owner submits new ratings + comments + file attachments → CRO/approver Approves or Rejects → on Approve, rating locks for the period and next-assessment-date advances. Period labels follow Indian FY (Apr–Mar). |
| **Score Trend Chart (NEW)** | Per-risk dual-axis line chart of approved review periods (2D max 25 / 3D max 75) |
| **Portfolio Movement (NEW)** | Dashboard tile counts risks that increased / reduced / unchanged / new since last approved review |
| **Score History** | Every save creates a dated history entry — full trend visibility |
| **Dashboard** | KPIs, heatmap (2D/3D), pie/bar/trend charts, portfolio movement, business exposure, assessment calendar |
| **Rating Matrix** | Editable impact, likelihood, and velocity scales — save to database |
| **Masters** | Add/edit/remove businesses, email contacts, approval matrix |
| **Documents** | Upload risk policies, manuals, appetite statements — view/edit/delete |
| **Import Excel** | Upload risks via provided template (now includes velocity columns) |
| **Export CSV** | Full register download (includes 3D scores and rating) |
| **Settings** | Company branding, logo upload, SMTP configuration |

---

## Scoring Reference

**2D (Impact × Likelihood, max 25):**
Low ≤ 4 · Medium 5–9 · High 10–14 · Critical ≥ 15

**3D (Impact × Likelihood × Velocity, max 75):**
Low ≤ 15 · Medium 16–30 · High 31–50 · Critical ≥ 51

**Velocity scale (time-to-impact):**
3 = High (rapid onset, hours to 30 days) ·
2 = Medium (30–90 days) ·
1 = Low (90 days to 1 year)

---

## Production Deployment

### Option A — Direct Python (any Linux/Mac server)

```bash
# Install dependencies
pip install -r requirements.txt

# Run with a specific port
PORT=8000 python main.py

# Or with Gunicorn for production
pip install gunicorn
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

### Option B — systemd service (Ubuntu/Debian)

Create `/etc/systemd/system/erm.service`:

```ini
[Unit]
Description=ERM Platform
After=network.target

[Service]
User=www-data
WorkingDirectory=/opt/erm-platform
ExecStart=/opt/erm-platform/venv/bin/gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
Restart=always
Environment=PORT=8000

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable erm
sudo systemctl start erm
```

### Option C — Nginx reverse proxy

```nginx
server {
    listen 80;
    server_name yourdomain.com;
    client_max_body_size 20M;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
    location /uploads {
        alias /opt/erm-platform/uploads;
    }
}
```

### Option D — Railway / Render / Fly.io

Add a `Procfile`:
```
web: gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:$PORT
```

Set environment variable: `PORT=8000`

**Note:** Use persistent volumes for `erm.db` and `uploads/` on cloud platforms.

---

## Database Backup

```bash
cp erm.db erm_backup_$(date +%Y%m%d).db
```

All data is in the single `erm.db` SQLite file.

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `PORT` | `8000` | Server port |
| `DB_PATH` | `erm.db` | SQLite database path |

---

## Project Structure

```
erm-platform/
├── main.py              # FastAPI routes
├── database.py          # SQLite schema + all DB operations
├── requirements.txt     # Python dependencies
├── erm.db               # Database (auto-created on first run)
├── uploads/             # Uploaded document files + review attachments
│   └── reviews/         # Per-risk review attachments (auto-created)
├── static/              # CSS/JS static files
└── templates/
    ├── base.html        # Shared layout, nav, styles
    ├── dashboard.html   # Executive dashboard with charts + portfolio movement
    ├── register.html    # Tabular risk register
    ├── risk_form.html   # Add/edit risk (vertical form, includes velocity)
    ├── risk_detail.html # Risk detail with approval workflow + periodic review
    ├── reviews.html     # Pending reviews list (Due / Submitted)
    ├── matrix.html      # Rating matrix (2D / 3D editable scales)
    ├── masters.html     # Businesses, contacts, approval matrix
    ├── documents.html   # Risk policies and documents
    └── settings.html    # Company settings and SMTP
```
